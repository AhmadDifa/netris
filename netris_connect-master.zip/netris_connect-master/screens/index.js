import SplashScreen from "./spashScreen";
import Login from "./login";
import Register from "./register";
import Nerby from "./nerby";
import Home from "./home";
import ProfileScreen from "./profileScreen";

export { SplashScreen, Login, Register, Nerby, Home, ProfileScreen };
